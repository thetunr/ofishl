# Installation and Setup

## For Windows and Mac
1. Unzip the file
2. Run the following commands in the terminal to set up the system:
   - ```make opam```
   - ```make build```
3. Run ```make run``` in the terminal to execute the game
4. Enjoy!

To view HTML documentation for our game, run ```make doc``` in the terminal.