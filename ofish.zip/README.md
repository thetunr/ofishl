# Welcome to OFishl, the Official OCaml Fishing Tournament!
## Names and NetIDS: 
  - Parker Rho (pkr47)
  - Sennet Senadheera (sas639)
  - Tony Oh (do256)
  - Aaron Song (ams799)

Our team used Raylib, a third-party graphics library with OCaml bindings, to create this game. 
Licensing and credit attribution can be viewed [here](licensing.md).
